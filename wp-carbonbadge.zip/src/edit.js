/**
 * React hook that is used to mark the block wrapper element.
 * It provides all the necessary props like the class name.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/packages/packages-block-editor/#useblockprops
 */
import { useBlockProps } from "@wordpress/block-editor";
import { useEffect } from "@wordpress/interactivity";

/**
 * The edit function describes the structure of your block in the context of the
 * editor. This represents what the editor will render when the block is used.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-edit-save/#edit
 *
 * @param {Object}   props               Properties passed to the function.
 * @param {Object}   props.attributes    Available block attributes.
 * @param {Function} props.setAttributes Function that updates individual attributes.
 *
 * @return {Element} Element to render.
 */
export default function Edit({ attributes, setAttributes }) {
  // const blockProps = useBlockProps();
  // const { darkMode } = attributes;
  const darkMode = false;
  const colorScheme = darkMode ? "wcb-d" : "";
  const badgeHTML = document.createElement("div");
  const carbonBadgeRef = React.createRef();
  const isAdminEnv = window.location.href.indexOf("wp-admin") > -1;
  const wcU = encodeURIComponent(
    isAdminEnv
      ? window.location.href.split("wp-admin")[0]
      : window.location.href
  );

  const newRequest = (e = !0) => {
    fetch(`https://api.websitecarbon.com/b?url=${wcU}`)
      .then((e) => {
        if (!e.ok) throw Error(e);
        return e.json();
      })
      .then((n) => {
        if (e) {
          renderResult(n);
        }
        n.t = new Date().getTime();
        localStorage.setItem(`wcb_${wcU}`, JSON.stringify(n));
      })
      .catch((e) => {
        const noResult = document.createElement("div", { id: "wcb_g" });
        noResult.innerHTML = "No Result";
        badgeHTML.appendChild(noResult);
        console.error(e);
        localStorage.removeItem(`wcb_${wcU}`);
      });
  };
  const renderResult = (e) => {
    const result = document.createElement("div", { id: "wcb_g" });
    result.innerHTML = `${e.c}g of CO<sub>2</sub>/view`;
    wcID("wcb_2").insertAdjacentHTML(
      "beforeEnd",
      "Cleaner than " + e.p + "% of pages tested"
    );
  };

  useEffect(() => {
    const wcB = document.createElement("div");
    if ("fetch" in window) {
      wcB.insertAdjacentHTML(
        "beforeEnd",
        '<div id="wcb_p"><span id="wcb_g">Measuring CO<sub>2</sub>&hellip;</span><a id="wcb_a" target="_blank" rel="noopener" href="https://websitecarbon.com">Website Carbon</a></div><span id="wcb_2">&nbsp;</span>'
      );
      let e = localStorage.getItem("wcb_" + wcU);
      const n = new Date().getTime();
      carbonBadgeRef.current.appendChild(wcB);
      if (e) {
        const t = JSON.parse(e);
        renderResult(t);
        if (n - t.t > 864e5) {
          newRequest(!1);
        }
      } else {
        newRequest();
      }
    }
  }, []);

  return (
    <div
      {...blockProps}
      dangerouslySetInnerHTML={badgeHTML}
      ref={carbonBadgeRef}
      id="wcb"
      className={`wcb carbonbadge ${colorScheme}`}
    ></div>
  );
}

// Edit.propTypes = {
//   attributes: PropTypes.shape({
//     darkMode: PropTypes.bool,
//   }),
//   setAttributes: PropTypes.func,
// };
